# VideoMasti MVP

यह Flutter का शुरुआती UI/MVP प्रोजेक्ट है।

## चलाने के लिए
1. Flutter SDK और Android Studio इंस्टॉल करें।
2. इस फ़ोल्डर में टर्मिनल खोलें।
3. `flutter pub get`
4. `flutter run`

## अभी क्या शामिल है
- Home video feed का demo
- Upload screen
- Earnings/Wallet screen
- Creator profile
- Bottom navigation

## अगला development चरण
- Firebase Authentication
- Real video upload/storage
- Video playback
- Likes/comments/follow
- Backend earnings ledger
- Admin panel
- Ad integration
- Withdrawal/KYC flow
- Moderation/report/block
- Play Store release configuration

नोट: यह production-ready earning app नहीं है; यह शुरुआती MVP/UI है।
