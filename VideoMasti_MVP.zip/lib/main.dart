import 'package:flutter/material.dart';

void main() => runApp(const VideoMastiApp());

class VideoMastiApp extends StatelessWidget {
  const VideoMastiApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'VideoMasti',
      theme: ThemeData(useMaterial3: true, colorSchemeSeed: Colors.deepPurple),
      home: const MainShell(),
    );
  }
}

class MainShell extends StatefulWidget {
  const MainShell({super.key});
  @override State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int index = 0;
  final pages = const [HomePage(), UploadPage(), WalletPage(), ProfilePage()];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('VideoMasti'), centerTitle: true),
      body: pages[index],
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (i) => setState(() => index = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'होम'),
          NavigationDestination(icon: Icon(Icons.add_circle_outline), selectedIcon: Icon(Icons.add_circle), label: 'अपलोड'),
          NavigationDestination(icon: Icon(Icons.account_balance_wallet_outlined), selectedIcon: Icon(Icons.account_balance_wallet), label: 'कमाई'),
          NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'प्रोफाइल'),
        ],
      ),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});
  @override
  Widget build(BuildContext context) {
    final videos = ['मजेदार वीडियो', 'आज का ट्रेंडिंग वीडियो', 'क्रिएटर वीडियो'];
    return ListView.builder(
      padding: const EdgeInsets.all(12),
      itemCount: videos.length,
      itemBuilder: (_, i) => Card(
        clipBehavior: Clip.antiAlias,
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Container(height: 210, color: Colors.black12,
            child: const Center(child: Icon(Icons.play_circle_fill, size: 70))),
          Padding(
            padding: const EdgeInsets.all(12),
            child: Row(children: [
              Expanded(child: Text(videos[i], style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold))),
              IconButton(onPressed: () {}, icon: const Icon(Icons.favorite_border)),
              IconButton(onPressed: () {}, icon: const Icon(Icons.share_outlined)),
            ]),
          )
        ]),
      ),
    );
  }
}

class UploadPage extends StatelessWidget {
  const UploadPage({super.key});
  @override
  Widget build(BuildContext context) => Center(
    child: Padding(
      padding: const EdgeInsets.all(24),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        const Icon(Icons.video_library, size: 80),
        const SizedBox(height: 16),
        const Text('अपना वीडियो अपलोड करें', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
        const SizedBox(height: 16),
        FilledButton.icon(
          onPressed: () => ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('वीडियो picker अगले चरण में जोड़ा जाएगा।'))),
          icon: const Icon(Icons.upload_file), label: const Text('वीडियो चुनें')),
      ]),
    ),
  );
}

class WalletPage extends StatelessWidget {
  const WalletPage({super.key});
  @override
  Widget build(BuildContext context) => ListView(
    padding: const EdgeInsets.all(20),
    children: [
      const Text('मेरी कमाई', style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
      const SizedBox(height: 12),
      Card(child: Padding(padding: const EdgeInsets.all(24),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: const [
          Text('उपलब्ध बैलेंस'), SizedBox(height: 8),
          Text('₹0.00', style: TextStyle(fontSize: 36, fontWeight: FontWeight.bold)),
          SizedBox(height: 8), Text('यह MVP केवल UI डेमो है। असली कमाई के लिए backend और ad/creator revenue system जोड़ना होगा.')
        ]))),
      const SizedBox(height: 12),
      FilledButton(onPressed: () {}, child: const Text('Withdrawal Request')),
    ],
  );
}

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});
  @override
  Widget build(BuildContext context) => ListView(
    padding: const EdgeInsets.all(20),
    children: const [
      CircleAvatar(radius: 48, child: Icon(Icons.person, size: 50)),
      SizedBox(height: 12),
      Center(child: Text('My Creator Profile', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold))),
      SizedBox(height: 24),
      ListTile(leading: Icon(Icons.video_library), title: Text('मेरे वीडियो'), trailing: Icon(Icons.chevron_right)),
      ListTile(leading: Icon(Icons.people), title: Text('Followers'), trailing: Text('0')),
      ListTile(leading: Icon(Icons.settings), title: Text('Settings'), trailing: Icon(Icons.chevron_right)),
    ],
  );
}
